<?php 

session_start();

echo session_id();


?>